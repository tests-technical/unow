<?php

/**
 * Class SampleTest
 *
 * @package Jonacruz_01
 */

use PHPUnit\Framework\TestCase;

/**
 * Sample test case.
 */
class SampleTest extends TestCase
{

	/**
	 * A single example test.
	 */
	public function test_sample()
	{
		// Replace this with some actual testing code.
		$this->assertTrue(true);
	}
}
